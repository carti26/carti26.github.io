import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class r8 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class r8 extends Auto
{
    private double BEWEGUNGSGESCHWINDIGKEIT = 0.1;
    private int i = 0;
    Auto myAuto = new Auto();

    public r8()
    {
        myAuto.starte();
    }

    /**
     * Act - do whatever the r8 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (myAuto.couldStart = false)
        {
            System.out.println("Schummler!");		
        }
        else{
            if (getX() < 900) {
                if (i<10) {
                    setLocation(50,50);
                    i++;
                }
                else {
                    if (Greenfoot.isKeyDown("a")) {
                        drehe(-7);
                    }
                    if (Greenfoot.isKeyDown("d")) {
                        drehe(7);
                    }
                    if (Greenfoot.isKeyDown("w")) {
                        BEWEGUNGSGESCHWINDIGKEIT = BEWEGUNGSGESCHWINDIGKEIT + 0.1;
                    }
                    if (Greenfoot.isKeyDown("s")) {
                        BEWEGUNGSGESCHWINDIGKEIT = BEWEGUNGSGESCHWINDIGKEIT - 0.1;
                    }
                    bewege();
                }
            }
            else {
                System.out.println("War ja klar, wer gewinnt...... der AUDI R8");
                Greenfoot.setWorld(new AudiWinner());
                Greenfoot.stop();
            }
        }
    }

    public void bewege()
    {
        double grad = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(grad) * BEWEGUNGSGESCHWINDIGKEIT);
        int y = (int) Math.round(getY() + Math.sin(grad) * BEWEGUNGSGESCHWINDIGKEIT);

        setLocation(x, y);
    }
}
