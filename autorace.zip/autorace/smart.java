import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class smart here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class smart extends Auto
{
    private double BEWEGUNGSGESCHWINDIGKEIT = 0.0;
    private int i = 0;
    private boolean nitro = true;

    /**
     * Act - do whatever the smart wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (getX() < 900) {
            if (i<10) {
                setLocation(50,200);
                i++;
            }
            else {
                if (Greenfoot.isKeyDown("left")) {
                    drehe(-7);
                }
                if (Greenfoot.isKeyDown("right")) {
                    drehe(7);
                }
                if (Greenfoot.isKeyDown("up")) {
                    BEWEGUNGSGESCHWINDIGKEIT = BEWEGUNGSGESCHWINDIGKEIT + 0.1;
                }
                if (Greenfoot.isKeyDown("down")) {
                    BEWEGUNGSGESCHWINDIGKEIT = BEWEGUNGSGESCHWINDIGKEIT - 0.1;
                }
                
                //Nitrofreigabe
                if (Greenfoot.isKeyDown("n")) {
                    if (nitro == true) {
                        if (getX() < 200) {
                            BEWEGUNGSGESCHWINDIGKEIT = BEWEGUNGSGESCHWINDIGKEIT + 1;
                            nitro = false;
                        }
                        else {
                            BEWEGUNGSGESCHWINDIGKEIT = BEWEGUNGSGESCHWINDIGKEIT + 0.1;
                        }
                    }
                    if (nitro == false) {
                        BEWEGUNGSGESCHWINDIGKEIT = BEWEGUNGSGESCHWINDIGKEIT + 0.1;
                    }
                }
                bewege();
            }
        }
        else {
            Greenfoot.setWorld(new Really());
            Greenfoot.stop();
        }
    }

    public void bewege()
    {
        double grad = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(grad) * BEWEGUNGSGESCHWINDIGKEIT);
        int y = (int) Math.round(getY() + Math.sin(grad) * BEWEGUNGSGESCHWINDIGKEIT);

        setLocation(x, y);
    }
}
