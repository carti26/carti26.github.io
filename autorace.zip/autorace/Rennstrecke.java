import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Rennstrecke extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public Rennstrecke()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1000, 300, 1); 
        prepare();
        //Greenfoot.playSound("sound.m4a");
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        r8 r8 = new r8();
        addObject(r8,50,30);
        smart smart = new smart();
        addObject(smart,50,230);
        Auto countdown = new Auto();
        addObject(countdown,500,150);
        countdown.starte();
    }
}
