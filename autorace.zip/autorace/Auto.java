import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;

/**
 * Write a description of class Auto here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Auto extends Actor
{
    private int count; // the counter field
    private int initialCount; // the initial time given before event occurs
    private boolean running;
    private boolean getsStarted = false;
    public boolean couldStart = false;
    private int timeBeforeEvent = 6;
    
    /**
     * Konstruktor der Klasse Tier - hier wird nichts gemacht.
     */
    public Auto()
    {
        
    }

    public void starte()
    {
        setTimer(timeBeforeEvent);
        updateImage();
        running = getsStarted;
    }
    
    /**
     * Drehe den uebergebenen Wert in Grad nach rechts.
     * Das p vor pGrad zeigt an, dass es ein Parameter (Uebergabewert) ist.
     */
    public void drehe(int pGrad)
    {
        setRotation(getRotation() + pGrad);
    } 

    public void setTimer(int timeBeforeEvent)
    {
        initialCount = 60 * timeBeforeEvent;
        count = -initialCount;
    }

    private void updateImage()
    {
        if (timeBeforeEvent >=2)
        {
            count++;
            timeBeforeEvent --;
            if ((count + initialCount) % 60 == 0) updateImage();
            int time = count * (int)Math.signum(count);
            time = time / 60;
            int secs = time % 60;
            time = (time - secs) / 60;
            String s = "" + secs;
            String text = s;
            GreenfootImage textImage = new GreenfootImage(text, 40, Color.red, new Color(0, 0, 0, 0));
            GreenfootImage image = new GreenfootImage(textImage.getWidth()+20, textImage.getHeight()+10);
            image.drawImage(textImage, (image.getWidth()-textImage.getWidth())/2, (image.getHeight()-textImage.getHeight())/2);
            setImage(image);
        }
        else if (timeBeforeEvent == 1)
        {
            timeBeforeEvent --;
            couldStart = true;
            String text = "GO";
            GreenfootImage textImage = new GreenfootImage(text, 50, Color.red, new Color(0, 0, 0, 0));
            GreenfootImage image = new GreenfootImage(textImage.getWidth()+20, textImage.getHeight()+10);
            image.drawImage(textImage, (image.getWidth()-textImage.getWidth())/2, (image.getHeight()-textImage.getHeight())/2);
            setImage(image);
        }
        else
        {
            String text = "";
            GreenfootImage textImage = new GreenfootImage(text, 50, Color.red, new Color(0, 0, 0, 0));
            GreenfootImage image = new GreenfootImage(textImage.getWidth()+20, textImage.getHeight()+10);
            image.drawImage(textImage, (image.getWidth()-textImage.getWidth())/2, (image.getHeight()-textImage.getHeight())/2);
            setImage(image);
        }
    }

    public void act()
    {
        setLocation(500,150);
        
        if (Greenfoot.isKeyDown("p"))
        {
            start();
        }
        
        if (running == true)
        {
            count++;
            if ((count + initialCount) % 60 == 0) updateImage();
        }
    }

    public int getTime()
    {
        return count / 60;
    }

    public void start()
    {
        running = true;
    }
}
